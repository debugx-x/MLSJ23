## Code for real-time prediction ##

import cv2
import tensorflow as tf
import numpy as np

class_names = ["Angry", "Disgust", "Fear", "Happy", "Neutral", "Sad", "Surprise"]

# Load the model with error handling
try:
    model = tf.keras.models.load_model("model_seq_optimal.h5")
except OSError as e:
    print("Failed to load the model:", e)
    exit(1)

# create a flag for grayscale or color image
is_color = False

# Create a video capture object
video = cv2.VideoCapture(0)

# Check if the video capture is successful
if not video.isOpened():
    print("Failed to open the video capture")
    exit(1)

faceDetect = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")

while True:
    ret, frame = video.read()

    if not ret:
        print("Failed to read a frame from the video capture")
        break

    if is_color:
        frame_color = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # Convert the frame to RGB
    else:
        frame_color = cv2.cvtColor(
            frame, cv2.COLOR_BGR2GRAY
        )  # Convert the frame to grayscale

    # Detect face in the frame
    faces = faceDetect.detectMultiScale(frame_color, 1.3, 3)

    # Draw a rectangle around the face
    for x, y, w, h in faces:
        # Crop the face
        sub_face_img = frame_color[y : y + h, x : x + w]

        # Resize the face to 48x48 pixels as required by the model
        if is_color:
            resized = cv2.resize(sub_face_img, (224, 224))
        else:
            resized = cv2.resize(sub_face_img, (48, 48))

        # Normalize the resized image
        normalize = resized / 255.0

        # Reshape the normalized image as required by the model
        if is_color:
            reshaped = np.reshape(normalize, (1, 224, 224, 3))
        else:
            reshaped = np.reshape(normalize, (1, 48, 48, 1))

        # Predict the emotion
        result = model.predict(reshaped)

        # Get the label of the predicted emotion
        label = np.argmax(result, axis=1)[0]

        # Print the label
        print(label)

        # Draw a rectangle around the face
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 1)
        cv2.rectangle(frame, (x, y), (x + w, y + h), (50, 50, 255), 2)

        # Draw a rectangle around the label
        cv2.rectangle(frame, (x, y - 40), (x + w, y), (50, 50, 255), -1)

        # Put the label text above the label rectangle
        cv2.putText(
            frame,
            class_names[label],
            (x, y - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (255, 255, 255),
            2,
        )

    # Display the frame
    cv2.imshow("Facial Emotion Recognition", frame)

    # Wait for key press and exit if 'q' is pressed
    k = cv2.waitKey(1)
    if k == ord("q"):
        break

# Release the video capture and close all windows
video.release()
cv2.destroyAllWindows()
